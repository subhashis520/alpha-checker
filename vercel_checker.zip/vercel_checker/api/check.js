export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.method === 'OPTIONS') return res.status(200).end();

  const { service, number } = req.body || {};
  let num = String(number||'').replace(/\D/g,'');
  if (num.length===12 && num.startsWith('91')) num = num.slice(2);
  if (num.length!==10) return res.json({ok:false,detail:'Invalid'});

  const h = {'User-Agent':'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4) AppleWebKit/605.1.15','Accept':'application/json','Content-Type':'application/json'};

  const apis = {
    jiomart:  ['https://www.jiomart.com/api/customer/v2/login/sendotp', {mobile:num,countryCode:'+91'}, {'Origin':'https://www.jiomart.com'}],
    swiggy:   ['https://api-orange.swiggy.com/dapi/auth/number-login', {mobile:num}, {'Origin':'https://www.swiggy.com'}],
    blinkit:  ['https://blinkit.com/v1/auth/phone-send-otp/', {phone:num,source:'web'}, {'app_client':'consumer_web'}],
    zomato:   ['https://api.zomato.com/api/v2.1/auth/otp_request', {contact:num,country_code:91,type:1}, {'x-zomato-isui':'true'}],
    flipkart: ['https://api.flipkart.net/mobile-api/mapi/login/mobile-otp', {mobileNumber:num,type:'LOGIN'}, {}],
    meesho:   ['https://meesho.com/api/v1/user/send-otp', {phone_number:'91'+num,channel:'WHATSAPP'}, {}],
    paytm:    ['https://acclogin.paytm.com/v3/login/sendOTP', {mobile:num,client_id:'C11',version:'2',channel_code:'WEB'}, {}],
    dream11:  ['https://api.dream11.com/apis/v4/login/getOTP', {mobile:num,country_code:'+91'}, {platform:'web'}],
    myntra:   ['https://www.myntra.com/gateway/v1/user/phonepe/otp/send', {phoneNumber:num,countryCode:'91'}, {'X-Location-Context':'IN'}],
    nykaa:    ['https://api.nykaa.com/v1/login/send-otp', {mobile:num,country_code:'91',type:'mobile'}, {}],
  };

  if (!apis[service]) return res.json({ok:false,registered:false,detail:'Not supported'});

  const [url, body, extra] = apis[service];
  try {
    const r = await fetch(url, {method:'POST', headers:{...h,...extra}, body:JSON.stringify(body)});
    const j = await r.json().catch(()=>({}));
    // Meesho has explicit is_registered field
    if (service==='meesho' && 'is_registered' in j)
      return res.json({ok:true, registered:!!j.is_registered, detail: j.is_registered?'Registered ✓':'Not registered'});
    // Generic: HTTP 200 = registered, 4xx = not
    const msg = (j.message||j.statusMessage||j.errorMessage||'').toLowerCase();
    const notReg = msg.includes('not') || msg.includes('invalid') || msg.includes('no account') || r.status===404 || r.status===400;
    res.json({ok:true, registered: r.status===200 && !notReg, detail: j.message||j.statusMessage||'HTTP '+r.status});
  } catch(e) {
    res.json({ok:false, registered:false, detail:'Error: '+e.message});
  }
}
